package com.csc483.assignment.sorting;

/**
 * Provides implementations of three sorting algorithms for empirical analysis:
 * Insertion Sort, Merge Sort, and Quick Sort.
 *
 * <p>All methods sort integer arrays in ascending order.
 * Comparison and swap counters are exposed as static fields for benchmarking.
 *
 * <p>Complexity Summary:
 * <pre>
 * Algorithm      | Best       | Average    | Worst      | Space  | Stable?
 * ---------------|------------|------------|------------|--------|--------
 * Insertion Sort | O(n)       | O(n²)      | O(n²)      | O(1)   | Yes
 * Merge Sort     | O(n log n) | O(n log n) | O(n log n) | O(n)   | Yes
 * Quick Sort     | O(n log n) | O(n log n) | O(n²)      | O(log n)| No
 * </pre>
 *
 * @author [Student Name]
 * @version 1.0
 */
public class SortingAlgorithms {

    /** Number of element comparisons in the last sort call */
    public static long comparisonCount = 0;

    /** Number of element swaps/assignments in the last sort call */
    public static long swapCount = 0;

    // ============================ INSERTION SORT ============================

    /**
     * Sorts an integer array using Insertion Sort.
     *
     * <p>Strategy: Builds a sorted sub-array one element at a time by
     * shifting elements right until the correct position is found.
     *
     * <p>Best for: small arrays (n < 1000) or nearly-sorted data.
     *
     * @param arr the array to sort (modified in place)
     */
    public static void insertionSort(int[] arr) {
        if (arr == null || arr.length <= 1) return;
        comparisonCount = 0;
        swapCount = 0;

        for (int i = 1; i < arr.length; i++) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0) {
                comparisonCount++;
                if (arr[j] > key) {
                    arr[j + 1] = arr[j]; // shift right
                    swapCount++;
                    j--;
                } else {
                    break;
                }
            }
            arr[j + 1] = key;
            swapCount++; // placement of key
        }
    }

    // ============================ MERGE SORT ============================

    /**
     * Sorts an integer array using Merge Sort (top-down recursive).
     *
     * <p>Strategy: Divides array in half, recursively sorts each half,
     * then merges the two sorted halves.
     *
     * <p>Best for: large datasets, guaranteed O(n log n), stable sort.
     *
     * @param arr the array to sort (modified in place)
     */
    public static void mergeSort(int[] arr) {
        if (arr == null || arr.length <= 1) return;
        comparisonCount = 0;
        swapCount = 0;
        mergeSortHelper(arr, 0, arr.length - 1);
    }

    /**
     * Recursive helper for Merge Sort.
     *
     * @param arr   the array being sorted
     * @param left  start index of sub-array
     * @param right end index of sub-array (inclusive)
     */
    private static void mergeSortHelper(int[] arr, int left, int right) {
        if (left >= right) return;

        int mid = left + (right - left) / 2;
        mergeSortHelper(arr, left, mid);
        mergeSortHelper(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }

    /**
     * Merges two sorted halves of an array in-place using a temporary buffer.
     *
     * @param arr   the array
     * @param left  start of left half
     * @param mid   end of left half
     * @param right end of right half
     */
    private static void merge(int[] arr, int left, int mid, int right) {
        int leftSize  = mid - left + 1;
        int rightSize = right - mid;

        int[] leftArr  = new int[leftSize];
        int[] rightArr = new int[rightSize];

        // Copy into temp arrays
        for (int i = 0; i < leftSize; i++)  leftArr[i]  = arr[left + i];
        for (int j = 0; j < rightSize; j++) rightArr[j] = arr[mid + 1 + j];

        int i = 0, j = 0, k = left;
        while (i < leftSize && j < rightSize) {
            comparisonCount++;
            if (leftArr[i] <= rightArr[j]) {
                arr[k++] = leftArr[i++];
            } else {
                arr[k++] = rightArr[j++];
            }
            swapCount++;
        }
        while (i < leftSize)  { arr[k++] = leftArr[i++];   swapCount++; }
        while (j < rightSize) { arr[k++] = rightArr[j++];  swapCount++; }
    }

    // ============================ QUICK SORT ============================

    /**
     * Sorts an integer array using Quick Sort with median-of-three pivot selection.
     *
     * <p>Strategy: Selects a pivot, partitions elements around it, then
     * recursively sorts each partition. Median-of-three reduces worst-case
     * probability on sorted/reverse-sorted inputs.
     *
     * <p>Best for: general-purpose sorting on random data; fastest in practice.
     *
     * @param arr the array to sort (modified in place)
     */
    public static void quickSort(int[] arr) {
        if (arr == null || arr.length <= 1) return;
        comparisonCount = 0;
        swapCount = 0;
        quickSortHelper(arr, 0, arr.length - 1);
    }

    /**
     * Recursive helper for Quick Sort.
     *
     * @param arr  the array
     * @param low  start index
     * @param high end index (inclusive)
     */
    private static void quickSortHelper(int[] arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSortHelper(arr, low, pivotIndex - 1);
            quickSortHelper(arr, pivotIndex + 1, high);
        }
    }

    /**
     * Partitions the sub-array around a pivot using Lomuto scheme.
     * Pivot is selected using median-of-three (first, mid, last).
     *
     * @param arr  the array
     * @param low  start index
     * @param high end index
     * @return final index of the pivot element
     */
    private static int partition(int[] arr, int low, int high) {
        // Median-of-three pivot
        int mid = low + (high - low) / 2;
        if (arr[low] > arr[mid])  { swap(arr, low, mid); }
        if (arr[low] > arr[high]) { swap(arr, low, high); }
        if (arr[mid] > arr[high]) { swap(arr, mid, high); }
        // arr[mid] is now the median; move to high-1 as pivot
        swap(arr, mid, high);
        int pivot = arr[high];

        int i = low - 1;
        for (int j = low; j < high; j++) {
            comparisonCount++;
            if (arr[j] <= pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        return i + 1;
    }

    /**
     * Swaps two elements in an array.
     *
     * @param arr the array
     * @param i   index of first element
     * @param j   index of second element
     */
    private static void swap(int[] arr, int i, int j) {
        if (i == j) return;
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        swapCount++;
    }
}
