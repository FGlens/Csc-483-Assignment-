package com.csc483.assignment.sorting;

import java.util.Arrays;
import java.util.Random;

/**
 * Generates test datasets of various types for sorting algorithm benchmarks.
 *
 * <p>Supported dataset types:
 * <ul>
 *   <li>RANDOM         - uniformly random integers</li>
 *   <li>SORTED         - already sorted ascending</li>
 *   <li>REVERSE_SORTED - sorted descending</li>
 *   <li>NEARLY_SORTED  - 90% sorted, 10% randomly placed</li>
 *   <li>MANY_DUPLICATES- only 10 distinct values</li>
 * </ul>
 *
 * @author [Student Name]
 * @version 1.0
 */
public class DataGenerator {

    /** Fixed seed ensures reproducibility across benchmark runs */
    private static final Random RAND = new Random(1234);

    /** Enum of supported dataset types */
    public enum DataType {
        RANDOM, SORTED, REVERSE_SORTED, NEARLY_SORTED, MANY_DUPLICATES
    }

    /**
     * Generates an integer array of the given size and type.
     *
     * @param size the number of elements
     * @param type the type of dataset to generate
     * @return generated integer array
     * @throws IllegalArgumentException if size < 1 or type is null
     */
    public static int[] generate(int size, DataType type) {
        if (size < 1) throw new IllegalArgumentException("Size must be >= 1.");
        if (type == null) throw new IllegalArgumentException("DataType must not be null.");

        switch (type) {
            case RANDOM:          return generateRandom(size);
            case SORTED:          return generateSorted(size);
            case REVERSE_SORTED:  return generateReverseSorted(size);
            case NEARLY_SORTED:   return generateNearlySorted(size);
            case MANY_DUPLICATES: return generateManyDuplicates(size);
            default:              throw new IllegalArgumentException("Unknown type: " + type);
        }
    }

    /** Generates an array of random integers in range [0, size * 10). */
    private static int[] generateRandom(int size) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) arr[i] = RAND.nextInt(size * 10);
        return arr;
    }

    /** Generates an already ascending-sorted array [0, 1, 2, ..., n-1]. */
    private static int[] generateSorted(int size) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) arr[i] = i;
        return arr;
    }

    /** Generates a descending-sorted array [n-1, n-2, ..., 0]. */
    private static int[] generateReverseSorted(int size) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) arr[i] = size - i - 1;
        return arr;
    }

    /**
     * Generates a nearly-sorted array.
     * Starts with sorted data, then randomly swaps 10% of elements.
     */
    private static int[] generateNearlySorted(int size) {
        int[] arr = generateSorted(size);
        int swaps = Math.max(1, size / 10); // 10% of elements displaced
        for (int i = 0; i < swaps; i++) {
            int a = RAND.nextInt(size);
            int b = RAND.nextInt(size);
            int tmp = arr[a]; arr[a] = arr[b]; arr[b] = tmp;
        }
        return arr;
    }

    /**
     * Generates an array with many duplicate values.
     * Uses only 10 distinct integer values regardless of array size.
     */
    private static int[] generateManyDuplicates(int size) {
        final int DISTINCT_VALUES = 10;
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) arr[i] = RAND.nextInt(DISTINCT_VALUES);
        return arr;
    }

    /**
     * Creates an independent copy of an array.
     *
     * @param original the original array
     * @return a new array with the same contents
     */
    public static int[] copy(int[] original) {
        return Arrays.copyOf(original, original.length);
    }
}
