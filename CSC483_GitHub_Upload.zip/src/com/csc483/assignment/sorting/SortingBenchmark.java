package com.csc483.assignment.sorting;

import java.util.Arrays;

/**
 * Benchmarks Insertion Sort, Merge Sort, and Quick Sort across multiple
 * dataset sizes and types. Outputs formatted comparison tables.
 *
 * <p>Statistical analysis:
 * <ul>
 *   <li>Mean runtime averaged over 5 timed runs</li>
 *   <li>Standard deviation across those 5 runs</li>
 * </ul>
 *
 * @author [Student Name]
 * @version 1.0
 */
public class SortingBenchmark {

    private static final int[] SIZES       = {100, 1_000, 10_000, 100_000};
    private static final int   TIMED_RUNS  = 5;
    private static final int   WARMUP_RUNS = 2;

    public static void main(String[] args) {
        for (DataGenerator.DataType type : DataGenerator.DataType.values()) {
            runBenchmark(type);
        }

        System.out.println("\n================================================================");
        System.out.println("CONCLUSIONS");
        System.out.println("================================================================");
        System.out.println("- Quick Sort is fastest on average for RANDOM data");
        System.out.println("- Insertion Sort competitive only for n <= 1,000");
        System.out.println("- Merge Sort provides consistent O(n log n) on all data types");
        System.out.println("- Quick Sort (median-of-3) avoids worst case on sorted data");
        System.out.println("- Insertion Sort excels on NEARLY_SORTED data (approaches O(n))");
        System.out.println("- On MANY_DUPLICATES, all algorithms degrade slightly");
        System.out.println("================================================================");
    }

    /**
     * Runs benchmarks for all three algorithms across all dataset sizes for a given data type.
     *
     * @param type the type of dataset to benchmark on
     */
    private static void runBenchmark(DataGenerator.DataType type) {
        System.out.println("\n================================================================");
        System.out.println("  SORTING ALGORITHMS COMPARISON - " + type);
        System.out.println("================================================================");
        System.out.printf("%-10s %-15s %12s %15s %10s %10s%n",
                "Size", "Algorithm", "Time (ms)", "Comparisons", "Swaps", "StdDev");
        System.out.println("-".repeat(75));

        for (int size : SIZES) {
            int[] data = DataGenerator.generate(size, type);
            benchmarkAlgorithm("Insertion", size, data, SortingBenchmark::runInsertionSort);
            benchmarkAlgorithm("Merge",     size, data, SortingBenchmark::runMergeSort);
            benchmarkAlgorithm("Quick",     size, data, SortingBenchmark::runQuickSort);
            System.out.println();
        }
    }

    /**
     * Benchmarks a single algorithm on a given dataset and prints results.
     *
     * @param name    algorithm name (for display)
     * @param size    input size
     * @param data    the original dataset (will be copied for each run)
     * @param runner  functional interface to invoke the algorithm
     */
    private static void benchmarkAlgorithm(String name, int size, int[] data, AlgorithmRunner runner) {
        // Warmup
        for (int i = 0; i < WARMUP_RUNS; i++) {
            runner.run(DataGenerator.copy(data));
        }

        double[] times = new double[TIMED_RUNS];
        long totalComparisons = 0;
        long totalSwaps       = 0;

        for (int i = 0; i < TIMED_RUNS; i++) {
            int[] copy = DataGenerator.copy(data);
            long start = System.nanoTime();
            runner.run(copy);
            times[i] = (System.nanoTime() - start) / 1_000_000.0;
            totalComparisons += SortingAlgorithms.comparisonCount;
            totalSwaps       += SortingAlgorithms.swapCount;
        }

        double mean   = mean(times);
        double stddev = stddev(times, mean);

        System.out.printf("%-10d %-15s %12.3f %15d %10d %10.3f%n",
                size, name, mean,
                totalComparisons / TIMED_RUNS,
                totalSwaps / TIMED_RUNS,
                stddev);
    }

    // ==================== Statistical helpers ====================

    private static double mean(double[] values) {
        double sum = 0;
        for (double v : values) sum += v;
        return sum / values.length;
    }

    private static double stddev(double[] values, double mean) {
        double sumSq = 0;
        for (double v : values) sumSq += (v - mean) * (v - mean);
        return Math.sqrt(sumSq / values.length);
    }

    // ==================== Algorithm runners ====================

    @FunctionalInterface
    interface AlgorithmRunner { void run(int[] arr); }

    private static void runInsertionSort(int[] arr) { SortingAlgorithms.insertionSort(arr); }
    private static void runMergeSort(int[] arr)     { SortingAlgorithms.mergeSort(arr);     }
    private static void runQuickSort(int[] arr)     { SortingAlgorithms.quickSort(arr);     }
}
