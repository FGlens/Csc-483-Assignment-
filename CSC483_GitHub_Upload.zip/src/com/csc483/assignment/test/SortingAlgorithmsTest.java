package com.csc483.assignment.test;

import com.csc483.assignment.sorting.DataGenerator;
import com.csc483.assignment.sorting.SortingAlgorithms;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 test suite for {@link SortingAlgorithms}.
 * Verifies correctness of Insertion Sort, Merge Sort, and Quick Sort
 * on all dataset types and edge cases.
 *
 * @author [Student Name]
 * @version 1.0
 */
class SortingAlgorithmsTest {

    // ==================== INSERTION SORT TESTS ====================

    @Test
    @DisplayName("Insertion Sort - random array correctly sorted")
    void testInsertionSortRandom() {
        int[] arr = DataGenerator.generate(100, DataGenerator.DataType.RANDOM);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.insertionSort(arr);
        assertArrayEquals(expected, arr, "Insertion Sort should produce a sorted array");
    }

    @Test
    @DisplayName("Insertion Sort - already sorted array unchanged")
    void testInsertionSortAlreadySorted() {
        int[] arr = DataGenerator.generate(100, DataGenerator.DataType.SORTED);
        int[] expected = DataGenerator.copy(arr);

        SortingAlgorithms.insertionSort(arr);
        assertArrayEquals(expected, arr);
    }

    @Test
    @DisplayName("Insertion Sort - reverse sorted array")
    void testInsertionSortReverse() {
        int[] arr = DataGenerator.generate(100, DataGenerator.DataType.REVERSE_SORTED);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.insertionSort(arr);
        assertArrayEquals(expected, arr);
    }

    @Test
    @DisplayName("Insertion Sort - null array does not throw")
    void testInsertionSortNullArray() {
        assertDoesNotThrow(() -> SortingAlgorithms.insertionSort(null));
    }

    @Test
    @DisplayName("Insertion Sort - single element array unchanged")
    void testInsertionSortSingleElement() {
        int[] arr = {42};
        SortingAlgorithms.insertionSort(arr);
        assertArrayEquals(new int[]{42}, arr);
    }

    @Test
    @DisplayName("Insertion Sort - duplicate values sorted correctly")
    void testInsertionSortDuplicates() {
        int[] arr = DataGenerator.generate(100, DataGenerator.DataType.MANY_DUPLICATES);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.insertionSort(arr);
        assertArrayEquals(expected, arr);
    }

    // ==================== MERGE SORT TESTS ====================

    @Test
    @DisplayName("Merge Sort - random array correctly sorted")
    void testMergeSortRandom() {
        int[] arr = DataGenerator.generate(1000, DataGenerator.DataType.RANDOM);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.mergeSort(arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest
    @EnumSource(DataGenerator.DataType.class)
    @DisplayName("Merge Sort - correctly sorts all dataset types")
    void testMergeSortAllTypes(DataGenerator.DataType type) {
        int[] arr = DataGenerator.generate(500, type);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.mergeSort(arr);
        assertArrayEquals(expected, arr, "Merge Sort failed on type: " + type);
    }

    @Test
    @DisplayName("Merge Sort - null array does not throw")
    void testMergeSortNullArray() {
        assertDoesNotThrow(() -> SortingAlgorithms.mergeSort(null));
    }

    @Test
    @DisplayName("Merge Sort - empty array does not throw")
    void testMergeSortEmptyArray() {
        int[] arr = {};
        assertDoesNotThrow(() -> SortingAlgorithms.mergeSort(arr));
        assertArrayEquals(new int[]{}, arr);
    }

    // ==================== QUICK SORT TESTS ====================

    @Test
    @DisplayName("Quick Sort - random array correctly sorted")
    void testQuickSortRandom() {
        int[] arr = DataGenerator.generate(1000, DataGenerator.DataType.RANDOM);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.quickSort(arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest
    @EnumSource(DataGenerator.DataType.class)
    @DisplayName("Quick Sort - correctly sorts all dataset types")
    void testQuickSortAllTypes(DataGenerator.DataType type) {
        int[] arr = DataGenerator.generate(500, type);
        int[] expected = DataGenerator.copy(arr);
        Arrays.sort(expected);

        SortingAlgorithms.quickSort(arr);
        assertArrayEquals(expected, arr, "Quick Sort failed on type: " + type);
    }

    @Test
    @DisplayName("Quick Sort - null array does not throw")
    void testQuickSortNullArray() {
        assertDoesNotThrow(() -> SortingAlgorithms.quickSort(null));
    }

    @Test
    @DisplayName("Quick Sort - two-element array sorted correctly")
    void testQuickSortTwoElements() {
        int[] arr = {5, 2};
        SortingAlgorithms.quickSort(arr);
        assertArrayEquals(new int[]{2, 5}, arr);
    }

    // ==================== COMPARISON COUNTS ====================

    @Test
    @DisplayName("Comparison count - Merge Sort compares roughly n log n times")
    void testMergeSortComparisonCount() {
        int n = 1024; // exact power of 2 for clean log2
        int[] arr = DataGenerator.generate(n, DataGenerator.DataType.RANDOM);
        SortingAlgorithms.mergeSort(arr);

        long theoretical = (long)(n * Math.log(n) / Math.log(2));
        // Allow generous margin — actual comparisons vary by data
        assertTrue(SortingAlgorithms.comparisonCount <= theoretical * 2,
                "Merge Sort comparisons (" + SortingAlgorithms.comparisonCount +
                ") should be close to n log n (" + theoretical + ")");
    }

    @Test
    @DisplayName("Comparison count - Insertion Sort on sorted array is O(n)")
    void testInsertionSortBestCaseComparisons() {
        int n = 1000;
        int[] arr = DataGenerator.generate(n, DataGenerator.DataType.SORTED);
        SortingAlgorithms.insertionSort(arr);

        // Best case: n-1 comparisons (one per outer loop pass)
        assertEquals(n - 1, SortingAlgorithms.comparisonCount,
                "Insertion Sort on sorted data should do exactly n-1 comparisons");
    }
}
