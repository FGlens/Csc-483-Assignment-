package com.csc483.assignment.test;

import com.csc483.assignment.search.Product;
import com.csc483.assignment.search.ProductSearch;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 test suite for {@link ProductSearch}.
 * Covers correctness of sequential search, binary search, name search,
 * and the hybrid insert/index functionality. Includes edge cases.
 *
 * @author [Student Name]
 * @version 1.0
 */
class ProductSearchTest {

    private static Product[] sortedProducts;
    private static final int ARRAY_SIZE = 10;

    @BeforeAll
    static void setup() {
        sortedProducts = new Product[ARRAY_SIZE];
        for (int i = 0; i < ARRAY_SIZE; i++) {
            sortedProducts[i] = new Product(
                    (i + 1) * 10,                    // IDs: 10, 20, 30 ... 100
                    "Product_" + ((i + 1) * 10),
                    "Category_" + (i % 3),
                    1000.0 + i * 500,
                    i * 5
            );
        }
    }

    // ==================== SEQUENTIAL SEARCH TESTS ====================

    @Test
    @DisplayName("Sequential search - found at first position (best case)")
    void testSequentialSearchBestCase() {
        Product result = ProductSearch.sequentialSearchById(sortedProducts, 10);
        assertNotNull(result, "Should find product with ID 10");
        assertEquals(10, result.getProductId());
    }

    @Test
    @DisplayName("Sequential search - found at last position (worst case)")
    void testSequentialSearchWorstCase() {
        Product result = ProductSearch.sequentialSearchById(sortedProducts, 100);
        assertNotNull(result, "Should find product with ID 100");
        assertEquals(100, result.getProductId());
    }

    @Test
    @DisplayName("Sequential search - ID not present returns null")
    void testSequentialSearchNotFound() {
        Product result = ProductSearch.sequentialSearchById(sortedProducts, 999);
        assertNull(result, "Should return null for missing ID");
    }

    @Test
    @DisplayName("Sequential search - null array throws exception")
    void testSequentialSearchNullArray() {
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.sequentialSearchById(null, 10));
    }

    // ==================== BINARY SEARCH TESTS ====================

    @Test
    @DisplayName("Binary search - found at middle position")
    void testBinarySearchMiddle() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 50);
        assertNotNull(result, "Should find product with ID 50");
        assertEquals(50, result.getProductId());
    }

    @Test
    @DisplayName("Binary search - found at first position")
    void testBinarySearchFirst() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 10);
        assertNotNull(result);
        assertEquals(10, result.getProductId());
    }

    @Test
    @DisplayName("Binary search - found at last position")
    void testBinarySearchLast() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 100);
        assertNotNull(result);
        assertEquals(100, result.getProductId());
    }

    @Test
    @DisplayName("Binary search - ID not in array returns null")
    void testBinarySearchNotFound() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 55);
        assertNull(result, "Should return null for ID not in array");
    }

    @Test
    @DisplayName("Binary search - null array throws exception")
    void testBinarySearchNullArray() {
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.binarySearchById(null, 10));
    }

    @ParameterizedTest
    @ValueSource(ints = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100})
    @DisplayName("Binary search - all valid IDs found correctly")
    void testBinarySearchAllIds(int id) {
        Product result = ProductSearch.binarySearchById(sortedProducts, id);
        assertNotNull(result, "Should find ID " + id);
        assertEquals(id, result.getProductId());
    }

    // ==================== NAME SEARCH TESTS ====================

    @Test
    @DisplayName("Name search - existing name found (case-insensitive)")
    void testNameSearchFound() {
        Product result = ProductSearch.searchByName(sortedProducts, "product_10");
        assertNotNull(result);
    }

    @Test
    @DisplayName("Name search - non-existent name returns null")
    void testNameSearchNotFound() {
        Product result = ProductSearch.searchByName(sortedProducts, "NonExistentProduct");
        assertNull(result);
    }

    @Test
    @DisplayName("Name search - null inputs throw exception")
    void testNameSearchNullInputs() {
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.searchByName(null, "test"));
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.searchByName(sortedProducts, null));
    }

    // ==================== HYBRID INDEX TESTS ====================

    @Test
    @DisplayName("Hybrid - buildNameIndex creates correct index size")
    void testBuildNameIndex() {
        Map<String, Product> index = ProductSearch.buildNameIndex(sortedProducts);
        assertEquals(ARRAY_SIZE, index.size(), "Index should have one entry per product");
    }

    @Test
    @DisplayName("Hybrid - hybridSearchByName returns correct product")
    void testHybridSearchFound() {
        Map<String, Product> index = ProductSearch.buildNameIndex(sortedProducts);
        Product result = ProductSearch.hybridSearchByName(index, "Product_10");
        assertNotNull(result);
        assertEquals(10, result.getProductId());
    }

    @Test
    @DisplayName("Hybrid - hybridSearchByName returns null for unknown name")
    void testHybridSearchNotFound() {
        Map<String, Product> index = ProductSearch.buildNameIndex(sortedProducts);
        assertNull(ProductSearch.hybridSearchByName(index, "Ghost Product"));
    }

    // ==================== ADD PRODUCT TESTS ====================

    @Test
    @DisplayName("addProduct - inserts and maintains sorted order")
    void testAddProductMaintainsSortedOrder() {
        // Array with one free null slot
        Product[] extArr = new Product[ARRAY_SIZE + 1];
        System.arraycopy(sortedProducts, 0, extArr, 0, ARRAY_SIZE);

        Product newProd = new Product(55, "Mid Product", "Electronics", 9999, 1);
        ProductSearch.addProduct(extArr, newProd);

        // Verify sorted order after insertion
        for (int i = 0; i < extArr.length - 1; i++) {
            assertTrue(extArr[i].getProductId() < extArr[i + 1].getProductId(),
                    "Array should remain sorted after addProduct");
        }
    }

    @Test
    @DisplayName("addProduct - null inputs throw exception")
    void testAddProductNullInputs() {
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.addProduct(null, new Product(1, "X", "Y", 1.0, 1)));
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.addProduct(new Product[2], null));
    }

    @Test
    @DisplayName("addProduct - full array throws exception")
    void testAddProductFullArray() {
        Product[] full = new Product[ARRAY_SIZE];
        System.arraycopy(sortedProducts, 0, full, 0, ARRAY_SIZE);
        assertThrows(IllegalArgumentException.class,
                () -> ProductSearch.addProduct(full, new Product(999, "X", "Y", 1.0, 1)));
    }

    // ==================== EDGE CASES ====================

    @Test
    @DisplayName("Empty array - all search methods return null without error")
    void testEmptyArray() {
        Product[] empty = new Product[0];
        assertNull(ProductSearch.sequentialSearchById(empty, 1));
        assertNull(ProductSearch.binarySearchById(empty, 1));
        assertNull(ProductSearch.searchByName(empty, "x"));
    }

    @Test
    @DisplayName("Single-element array - search finds the element")
    void testSingleElement() {
        Product[] single = {new Product(42, "Solo", "Misc", 5000, 10)};
        assertNotNull(ProductSearch.sequentialSearchById(single, 42));
        assertNotNull(ProductSearch.binarySearchById(single, 42));
        assertNull(ProductSearch.binarySearchById(single, 99));
    }
}
