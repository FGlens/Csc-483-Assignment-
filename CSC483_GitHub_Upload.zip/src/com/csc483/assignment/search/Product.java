package com.csc483.assignment.search;

/**
 * Represents a product in the TechMart online store catalog.
 * Contains product details including ID, name, category, price, and stock quantity.
 *
 * @author [Student Name]
 * @version 1.0
 */
public class Product implements Comparable<Product> {

    /** Unique identifier for the product */
    private int productId;

    /** Name of the product */
    private String productName;

    /** Category the product belongs to */
    private String category;

    /** Price of the product in Naira */
    private double price;

    /** Number of items currently in stock */
    private int stockQuantity;

    /**
     * Constructs a new Product with the given attributes.
     *
     * @param productId     unique product ID
     * @param productName   name of the product
     * @param category      product category
     * @param price         product price
     * @param stockQuantity number of items in stock
     */
    public Product(int productId, String productName, String category,
                   double price, int stockQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    // ======================== Getters ========================

    /** @return the product ID */
    public int getProductId() { return productId; }

    /** @return the product name */
    public String getProductName() { return productName; }

    /** @return the product category */
    public String getCategory() { return category; }

    /** @return the product price */
    public double getPrice() { return price; }

    /** @return the stock quantity */
    public int getStockQuantity() { return stockQuantity; }

    // ======================== Setters ========================

    /** @param productName new product name */
    public void setProductName(String productName) { this.productName = productName; }

    /** @param category new category */
    public void setCategory(String category) { this.category = category; }

    /** @param price new price */
    public void setPrice(double price) { this.price = price; }

    /** @param stockQuantity new stock quantity */
    public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }

    /**
     * Compares products by productId for natural ordering.
     *
     * @param other the other Product to compare to
     * @return negative if this ID < other, 0 if equal, positive if greater
     */
    @Override
    public int compareTo(Product other) {
        return Integer.compare(this.productId, other.productId);
    }

    /**
     * Returns a string representation of this Product.
     *
     * @return formatted product info string
     */
    @Override
    public String toString() {
        return String.format("Product{ID=%d, Name='%s', Category='%s', Price=%.2f, Stock=%d}",
                productId, productName, category, price, stockQuantity);
    }
}
