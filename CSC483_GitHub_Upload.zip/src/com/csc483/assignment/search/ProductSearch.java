package com.csc483.assignment.search;

import java.util.HashMap;
import java.util.Map;

/**
 * Provides search operations for an array of Product objects.
 * Includes sequential search, binary search, and a hybrid name-based search
 * using a HashMap index for O(1) average-case name lookup.
 *
 * <p>Time Complexity Summary:
 * <ul>
 *   <li>Sequential Search: O(n) worst/average, O(1) best</li>
 *   <li>Binary Search:     O(log n) worst/average, O(1) best</li>
 *   <li>Name Index Search: O(1) average (HashMap lookup)</li>
 *   <li>addProduct (sorted): O(n) due to shifting elements</li>
 * </ul>
 *
 * @author [Student Name]
 * @version 1.0
 */
public class ProductSearch {

    /**
     * Comparison counter — reset before each timed experiment if needed.
     * Not thread-safe; intended for single-threaded benchmarking only.
     */
    public static long comparisonCount = 0;

    // ==================== SEQUENTIAL SEARCH ====================

    /**
     * Searches for a product by ID using sequential (linear) search.
     * Scans each element in order from index 0 to n-1.
     *
     * <p>Complexity: Best O(1) | Average O(n/2) | Worst O(n)
     *
     * @param products array of Product objects (need not be sorted)
     * @param targetId the product ID to search for
     * @return the matching Product, or null if not found
     * @throws IllegalArgumentException if products array is null
     */
    public static Product sequentialSearchById(Product[] products, int targetId) {
        if (products == null) {
            throw new IllegalArgumentException("Products array must not be null.");
        }

        comparisonCount = 0;
        for (int i = 0; i < products.length; i++) {
            comparisonCount++;
            if (products[i] != null && products[i].getProductId() == targetId) {
                return products[i];
            }
        }
        return null; // not found
    }

    // ==================== BINARY SEARCH ====================

    /**
     * Searches for a product by ID using binary search.
     * The products array MUST be sorted by productId in ascending order.
     *
     * <p>Precondition: products[] is sorted by productId (ascending).
     * <p>Complexity: Best O(1) | Average O(log n) | Worst O(log n)
     *
     * @param products array of Product objects sorted by productId
     * @param targetId the product ID to search for
     * @return the matching Product, or null if not found
     * @throws IllegalArgumentException if products array is null
     */
    public static Product binarySearchById(Product[] products, int targetId) {
        if (products == null) {
            throw new IllegalArgumentException("Products array must not be null.");
        }

        comparisonCount = 0;
        int low = 0;
        int high = products.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2; // avoids integer overflow
            comparisonCount++;

            if (products[mid] == null) {
                high = mid - 1;
                continue;
            }

            int midId = products[mid].getProductId();
            if (midId == targetId) {
                return products[mid];
            } else if (midId < targetId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null; // not found
    }

    // ==================== NAME SEARCH (SEQUENTIAL) ====================

    /**
     * Searches for a product by name using sequential search.
     * Because product names are not sorted, linear scan is necessary.
     * Case-insensitive comparison is used.
     *
     * <p>Complexity: Best O(1) | Average O(n/2) | Worst O(n)
     *
     * @param products   array of Product objects (unsorted by name)
     * @param targetName the product name to search for
     * @return the first matching Product, or null if not found
     * @throws IllegalArgumentException if products or targetName is null
     */
    public static Product searchByName(Product[] products, String targetName) {
        if (products == null || targetName == null) {
            throw new IllegalArgumentException("Arguments must not be null.");
        }

        comparisonCount = 0;
        for (Product product : products) {
            comparisonCount++;
            if (product != null && product.getProductName().equalsIgnoreCase(targetName)) {
                return product;
            }
        }
        return null;
    }

    // ==================== HYBRID: NAME INDEX ====================

    /**
     * Builds a HashMap index mapping product names (lowercase) to Product objects.
     * This allows O(1) average-case name lookup without scanning the array.
     *
     * <p>Complexity to build: O(n) | Lookup: O(1) average
     *
     * @param products array of Product objects
     * @return HashMap index from lowercase name to Product
     */
    public static Map<String, Product> buildNameIndex(Product[] products) {
        Map<String, Product> index = new HashMap<>();
        for (Product p : products) {
            if (p != null) {
                index.put(p.getProductName().toLowerCase(), p);
            }
        }
        return index;
    }

    /**
     * Searches for a product by name using the pre-built HashMap index.
     * Average O(1) lookup — significantly faster than sequential name search.
     *
     * @param nameIndex the HashMap index built by buildNameIndex()
     * @param targetName the product name to search for (case-insensitive)
     * @return the matching Product, or null if not found
     */
    public static Product hybridSearchByName(Map<String, Product> nameIndex, String targetName) {
        if (nameIndex == null || targetName == null) return null;
        return nameIndex.get(targetName.toLowerCase());
    }

    // ==================== HYBRID: SORTED INSERT ====================

    /**
     * Inserts a new product into a sorted array while maintaining sort order by productId.
     * Shifts elements right to make room — O(n) worst case.
     *
     * <p>Complexity: O(n) time | O(1) extra space (in-place)
     *
     * <p>Note: The array must have capacity for one extra element (last slot is null).
     *
     * @param products   sorted array of Products with one free slot at the end
     * @param newProduct the product to insert
     * @throws IllegalArgumentException if arguments are null or array has no free slot
     */
    public static void addProduct(Product[] products, Product newProduct) {
        if (products == null || newProduct == null) {
            throw new IllegalArgumentException("Arguments must not be null.");
        }
        if (products[products.length - 1] != null) {
            throw new IllegalArgumentException("Array has no free slot for insertion.");
        }

        // Find insertion position using binary search
        int low = 0, high = products.length - 2; // exclude last (null) slot
        int insertPos = products.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (products[mid] == null || products[mid].getProductId() > newProduct.getProductId()) {
                insertPos = mid;
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        // Shift elements right from insertPos onwards
        for (int i = products.length - 1; i > insertPos; i--) {
            products[i] = products[i - 1];
        }
        products[insertPos] = newProduct;
    }
}
